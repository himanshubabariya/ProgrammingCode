﻿namespace ProgrammingCode.DAL.PRO.PRO_ProgramTestCase
{
    public class PRO_ProgramTestCaseDAL:PRO_ProgramTestCaseDALBase
    {
    }
}
